<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<!-- CSS -->
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>deskapp/vendors/styles/core.css">
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>deskapp/vendors/styles/icon-font.min.css">
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>deskapp/src/plugins/datatables/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>deskapp/src/plugins/datatables/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>deskapp/vendors/styles/style.css">
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>deskapp/vendors/styles/core.css">
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>deskapp/vendors/styles/icon-font.min.css">
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>deskapp/src/plugins/datatables/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>deskapp/src/plugins/datatables/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>deskapp/vendors/styles/style.css">

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-119386393-1"></script>

<script>
$(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>

</script>
