		<div class="pd-ltr-20">

			<div class="row">
				<div class="col-md-6">

						<div class="card-box height-100-p pd-20">
							<h2 class="h4 mb-20">Jumlah Kunjungan Gardu</h2>
							<div id="chart5"></div>
						</div>

				</div>
			<div class="col-md-6">

						<div class="pd-20 card-box height-100-p">
							<h4 class="h4 text-blue">Persentasi Kunjungan Kerja Bulan Oktober</h4>
							<div id="chart8"></div>
						</div>

			</div>

			</div>

		</div>
